<!DOCTYPE php>
<php lang="en">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>The Earth NGO</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="description" content="At our NGO, we believe in the power of collective action to create lasting change. Our team is made up of passionate and dedicated individuals, each working towards a common goal: to improve the lives of those in need.Together, our team brings a diverse range of skills, experiences, and perspectives to our work. Whether it&#039;s supporting disaster relief efforts or running education programs, we are committed to making a lasting impact in the communities we serve.We are proud to work alongside like-minded individuals, both within our organization and in partnership with other NGOs and volunteers. Join us in our mission to bring hope and positive change to those in need.&quot;" />
   <meta name="keywords" content="Ngo , Ngo Foundation">
   <!-- Google Fonts -->
   <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&amp;display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;0,900;1,300;1,400;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
   <link rel="shortcut icon" href="https://theearth.ngo/public/uploads/logo/Earth Logo TM.png" type="image/x-icon">
   <!-- Stylesheets -->
   <link href="https://theearth.ngo/public/web/assets/css/font-awesome-all.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/flaticon.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/owl.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/swiper.min.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/bootstrap.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/jquery.fancybox.min.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/animate.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/jquery.bootstrap-touchspin.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/color.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/style.css" rel="stylesheet">
   <link href="https://theearth.ngo/public/web/assets/css/responsive.css" rel="stylesheet">
   <link rel="stylesheet" href="https://theearth.ngo/public/web/assets/css/required.css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
   

</head>
<body  oncontextmenu="return false">
   <div class="boxed_wrapper">
      <!-- preloader -->
      
      <!-- preloader end -->
      <!-- header section being -->
      <style>
   .top-inner p {
   position: relative;
   font-family: 'Nunito Sans', sans-serif;
   color: #fff;
   font-weight: 400;
   margin: 0px;
   transition: all 500ms ease;
   }
</style>
<!-- main header -->
<header class="main-header header-style-one">
   <!-- logo-box -->
   <div class="logo-box">
      <div class="shape" style="background-image: url(assets/images/shape/shape-1.png);"></div>
      <figure class="logo">   <a href="https://theearth.ngo"><img id="headerLogo" src="https://theearth.ngo/public/uploads/logo/Earth Logo TM.png" alt="The Earth NGO"></a></figure>
   </div>
   <!-- header-top -->
   <div class="header-top">
      <div class="outer-container">
         <div class="top-inner clearfix">
            <div class="left-column pull-left">
               <marquee behavior="scroll" direction="left" scrollamount="4" onmouseover="this.stop()" onmouseout="this.start()" style="font-size: 18px;font-weight: 600;margin-top: 3px;margin-bottom: -3px;border-top-right-radius: 25px; border-bottom-right-radius: 25px;">
                  <span style="display:flex;">  <img src="https://theearth.ngo/public/newicon.gif" style="height:10px;margin-top:10px;"> 
                  &nbsp;<p><q>&nbsp;I am writing to inform you about an upcoming event that may be of interest to your organization.</q></p></span>
               </marquee>
            </div>
            
         </div>
      </div>
      <!-- donate-btn -->
      <div class="donate-btn">
       
         
       
         
         <a href="https://theearth.ngo/donate" class="main-menu__btn"> <button class="donate-box-btn theme-btn btn-one"><i class="fa fa-inr" aria-hidden="true"></i> Donate Now</button>
         </a>&nbsp;&nbsp;
                           <a style="color:#232323" href="https://theearth.ngo/login"><b><i class="fa fa-user" aria-hidden="true"></i> Login /</b> <a style="color:#232323" href="https://theearth.ngo/register"><b>Register</b></a>
                           </a>
      </div>
   </div>
   <!-- header-lower -->
   <div class="header-lower">
      <div class="outer-container">
         <div class="outer-box">
            <a class="d-md-none d-block" href="https://theearth.ngo"><img id="headerLogo" src="https://theearth.ngo/public/uploads/logo/Earth Logo TM.png" alt="The Earth NGO"></a>
            <div class="menu-area clearfix">
               <!--Mobile Navigation Toggler-->
               <div class="mobile-nav-toggler">
                  <i class="icon-bar"></i>
                  <i class="icon-bar"></i>
                  <i class="icon-bar"></i>
               </div>
               <nav class="main-menu navbar-expand-md navbar-light">
                  <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                     <ul class="navigation clearfix">
                        <li>
                           <a href="https://theearth.ngo">Home </a>
                        </li>
                        <li class="dropdown">
                           <a>Pages</a>
                           <ul>
                                                                                          <li><a href="https://theearth.ngo/about-us/about">About Us</a></li>
                                                            <li><a href="https://theearth.ngo/our-team">Team</a></li>
                              <li><a href="https://theearth.ngo/linkage-authorization"> Authorization</a></li>
                              <li><a href="https://theearth.ngo/faqs">FAQ</a></li>
                             
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a>Work</a>
                           <ul>
                                                                                          <li><a href="https://theearth.ngo/works/SDG%20-5">SDG -5</a></li>
                                                            <li><a href="https://theearth.ngo/works/SDG%20-11">SDG -11</a></li>
                                                            <li><a href="https://theearth.ngo/works/SDG%20-13">SDG -13</a></li>
                                                            <li><a href="https://theearth.ngo/works/SDG%20-16">SDG -16</a></li>
                                                         </ul>
                        </li>
                        <li class="dropdown">
                           <a>Campaign</a>
                           <ul>
                                                                                          <li><a href="https://theearth.ngo/our-campaigns/35">SDG -5</a></li>
                                                            <li><a href="https://theearth.ngo/our-campaigns/36">SDG -11</a></li>
                                                            <li><a href="https://theearth.ngo/our-campaigns/37">SDG -13</a></li>
                                                            <li><a href="https://theearth.ngo/our-campaigns/38">SDG -16</a></li>
                                                         </ul>
                        </li>
                        <li class="dropdown">
                           <a>Member</a>
                           <ul>
                              <li><a href="https://theearth.ngo/join-us">Registration Form </a> </li>
                              <li><a  href="https://theearth.ngo/member/verification">Member's Verification </a> </li>
                              <!--<li><a  href="https://theearth.ngo/our/member">Our Member </a> </li>-->
                              <li><a href="https://theearth.ngo/login">Member Login </a> </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="#">Volunteer</a>
                           <ul>
                              <li><a href="https://theearth.ngo/volunteer/form">Registration Form </a> </li>
                              <li><a  href="https://theearth.ngo/volunteer/verification">Volunteer Verification </a> </li>
                              <!--<li><a  href="https://theearth.ngo/our/volunteer">Our Volunteer's </a> </li>-->
                              <li><a href="https://theearth.ngo/login">Volunteer Login </a> </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="#">Intership</a>
                           <ul>
                              <li><a href="https://theearth.ngo/Internship/form">Registration Form </a> </li>
                              <li><a  href="https://theearth.ngo/Intern/verification">Intership Verification </a> </li>
                              <li><a  href="https://theearth.ngo/Intern/Certificate">Intership Certificate </a> </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="#">Event</a>
                           <ul>
                              <li><a href="https://theearth.ngo/event">Upcoming Event</a> </li>
                              <li><a href="https://theearth.ngo/past-event">Past Event</a> </li>
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="#">Highlights</a>
                           <ul>
                              <!--<li><a href="https://theearth.ngo/our/award">Award </a> </li>-->
                              <li><a  href="https://theearth.ngo/our/achievement"> Achievment </a> </li>
                              <li><a  href="https://theearth.ngo/our/stories"> Story </a> </li>
                              <li><a href="https://theearth.ngo/news">News</a> </li>
                              <li><a href="https://theearth.ngo/press-release">Press Release </a> </li>
                              <li><a href="https://theearth.ngo/job">Career</a> </li>
                              <li><a href="https://theearth.ngo/our/blog">Blog</a> </li>
                       
                           </ul>
                        </li>
                        <li class="dropdown">
                           <a href="javascript:void(0);">Gallery</a>
                           <ul>
                              <li><a href="https://theearth.ngo/photo-gallery">Photo Gallery</a></li>
                              <li><a href="https://theearth.ngo/videos">Video Gallery</a></li>
                           </ul>
                        </li>
                        <li>
                           <a href="https://theearth.ngo/contact">Contact</a>
                          
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
   </div>
   <!--sticky Header-->
   <div class="sticky-header">
      <div class="auto-container">
         <div class="outer-box">
            <div class="menu-area clearfix">
               <nav class="main-menu clearfix">
                  <!--Keep This Empty / Menu will come through Javascript-->
               </nav>
            </div>
         </div>
      </div>
   </div>
</header>
<!-- main-header end -->
<!-- Mobile Menu  -->
<div class="mobile-menu">
   <div class="menu-backdrop"></div>
   <div class="close-btn"><i class="fas fa-times"></i></div>
   <nav class="menu-box">
      <div class="nav-logo"><a href="https://theearth.ngo"><img id="headerLogo" src="https://theearth.ngo/public/uploads/logo/Earth Logo TM.png" alt="The Earth NGO"></a></div>
      <div class="menu-outer">
         <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
      </div>
      <div class="contact-info">
         <h4>Contact Info</h4>
         <ul>
            <li>Samne Ghat, Nagwa Lanka, Varanasi, Uttar Pradesh 221005</li>
            <li><a href="tel:+91 9794412733">+91 9794412733</a></li>
            <li><a href="mailto:webcodian.official@gmail.com">webcodian.official@gmail.com</a></li>
         </ul>
      </div>
      <div class="social-links">
         <ul class="clearfix">
            <li><a href="https://twitter.com/apnashelterinfo"><span class="fab fa-twitter"></span></a></li>
            <li><a href="https://www.facebook.com/apnashelterindiafoundation/"><span class="fab fa-facebook-square"></span></a></li>
            <li><a href=""><span class="fab fa-instagram"></span></a></li>
            <li><a href="https://sushmafoundation/"><span class="fab fa-youtube"></span></a></li>
         </ul>
      </div>
   </nav>
</div>
<!-- End Mobile Menu -->      <!-- end -->
      <!-- main content being -->
      

 

<center>  <img src="public/web/404.gif">
<h3>Sorry We Can't Find That Page!</h3><br>
<p>The page you are looking for was moved, removed, renamed or never existed.</p><br>

  <a href="https://theearth.ngo" class="main-menu__btn"> <button class="donate-box-btn theme-btn btn-one">Take Me Home</button>
         </a>&nbsp;&nbsp;
</center>
<br>


      <!--end -->
      <!-- footer section being -->
      <!-- main-footer -->
        <section class="main-footer">
            <div class="footer-top">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget about-widget">
                                <div class="title-box">
                                    <div class="icon-box"><i class="icon-hand"></i></div>
                                    <span>Charity of Choice</span>
                                    <h3>Partner With Us</h3>
                                </div>
                                <div class="text">
                                    <p>Prevents our being able to do we like best, every pleasures is every pain avoided.</p>
                                    <a href="https://theearth.ngo/join-us" class="theme-btn btn-one">Join With Us</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml-30">
                                <div class="widget-title">
                                    <h3>Our Charity</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="https://theearth.ngo/linkage-authorization">Authorization</a></li>
                              
                                        <li><a href="https://theearth.ngo/event">Events</a></li>
                                        <li><a href="https://theearth.ngo/news">Latest News</a></li>
                                        <li><a href="https://theearth.ngo/our/blog">Blog</a></li>
                               <li><a href="https://theearth.ngo/faqs">FAQ</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget ml-30">
                                <div class="widget-title">
                                    <h3>Quick Links</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                               
                                                                                <li><a href="https://theearth.ngo/our/links/privacy-and-policy">Privacy and Policy</a></li>
                                                                                <li><a href="https://theearth.ngo/our/links/term-conditions">Term &amp; Conditions</a></li>
                                                                                <li><a href="https://theearth.ngo/our/links/refund-cancellation">Refund &amp; Cancellation</a></li>
                                                                            </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget contact-widget ml-30">
                               
                                <div class="widget-content">
                                    <div class="single-item">
                                        <h3><a href="tel:+91 9794412733">+91 9794412733</a></h3>
                                        <p><a href="mailto:mailto:webcodian.official@gmail.com">mailto:webcodian.official@gmail.com</a></p>
                                    </div>
                                    <div class="single-item">
                                        <h5>Charity Shop</h5>
                                        <p>Samne Ghat, Nagwa Lanka, Varanasi, Uttar Pradesh 221005</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="inner-box clearfix">
                        <div class="copyright">
                            <p style="text-align:center;">&copy; 2023 The Earth NGO All rights reserved . Developed By  <a target="_blank" href="https://webcodian.com/">Webcodian Pvt Ldt</a></p>
                        </div>
                        <!--<ul class="footer-card pull-right clearfix">-->
                        <!--    <li><span>Ways to Donate:</span></li>-->
                        <!--    <li><img src="https://theearth.ngo/public/web/assets/images/bg/paypal.png" alt="" style="height:30px;"></li>-->
                        <!--    <li><img src="https://theearth.ngo/public/web/assets/images/bg/razorpay.png" alt="" style="height:30px;"></li>-->
                         
                        <!--</ul>-->
                    </div>
                </div>
            </div>
        </section>
        <!-- main-footer end -->      <!-- end -->
  
      <a  data-toggle="modal" data-target="#donate_blood"  data-animation="animated slideInUp" class="float-button" blinking>
         <div class="float-button-text" style="color:#fff;">
            <span class="fa fa-tint"></span>&nbsp;  
            Donate Blood 
         </div>
      </a>
      <a target="_blank" href="https://api.whatsapp.com/send?phone=+919794412733&amp;text=The Earth NGO" class="whatsapp-button"><i class="fa fa-whatsapp"></i></a>
      <div class="quadrat" id="enquiry2">
      =
      </div>
   </div>
   <!--support modal tickets -->
   <!-- Modal -->
   <div class="modal" id="donate_blood">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header" style="background: #03c0a8;">
               <div class="section-title text-center mb-1 mt-1">
                  <span class="section-title__tagline" style="color:#fff;">Donate Blood</span>
               </div>
               <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="exampleModal">
               <form action="https://theearth.ngo/blood/donate/store" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="_token" value="">                  <div class="row">
                     <div class="form-group col-md-6 col-12 ">
                        <label for="recipient-name" class="col-form-label">Full Name *</label>
                        <input type="text" class="form-control " id="recipient-name" name="p_name" required placeholder="Full Name" value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label">Date of Birth  *</label>
                        <input name="dob" type="date" class="form-control " required  value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label"> Mobile Number *</label>
                        <input name="mobile" type="text" class="form-control " placeholder="Enter Mobile" required value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label"> Email *</label>
                        <input name="email" type="text" class="form-control " placeholder="Enter Email" required value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="message-text" class="col-form-label">Select Blood Group *</label>
                        <select class="form-control " name="blood_group" required>
                           <option selected disabled>Select Blood Group </option>
                           <option value="A+">A+</option>
                           <option value="A-" >A-</option>
                           <option value="B+">B+</option>
                           <option value="B-">B-</option>
                           <option value="AB+">AB+</option>
                           <option value="AB-">AB-</option>
                           <option value="O+">O+</option>
                           <option value="O-">O-</option>
                           <option value="Don't Know">Don't Know</option>
                        </select>
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label">Weight *</label>
                        <input name="weight" type="text" class="form-control " required value="" placeholder="Enter Weight">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label">Last time donated blood date *</label>
                        <input name="required_date" type="date" class="form-control " required value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="message-text" class="col-form-label">Have you ever been deferred or rejected as a donor *</label>
                        <select class="form-control " name="refer_by" required>
                           <option selected disabled>Select  </option>
                           <option value="Yes">Yes </option>
                           <option value="No">No</option>
                        </select>
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label">Current Living City  *</label>
                        <input name="city" type="text" class="form-control " placeholder="Enter City" required value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="recipient-name" class="col-form-label">Address *</label>
                        <input name="address" type="text" class="form-control " placeholder="Enter address" required value="">
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="message-text" class="col-form-label">Any medical conditions or allergies *</label>
                        <select class="form-control " name="medical_allergies" required>
                           <option selected disabled>Select  </option>
                           <option value="Yes">Yes </option>
                           <option value="No">No</option>
                        </select>
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="message-text" class="col-form-label">Any medication that you are currently taking *</label>
                        <select class="form-control " name="medical_taking" required>
                           <option selected disabled>Select  </option>
                           <option value="Yes">Yes </option>
                           <option value="No">No</option>
                        </select>
                                             </div>
                     <div class="form-group col-md-6 col-12">
                        <label for="message-text" class="col-form-label">How did you hear about The Earth NGO's blood donation drive *</label>
                        <select class="form-control " name="blood_donation" required>
                           <option selected disabled>Select  </option>
                           <option value="Website">Website </option>
                           <option value="Social Media">Social Media</option>
                           <option value="Friend">Friend</option>
                           <option value="Our Member">Our Member</option>
                           <option value="Our Volunteer">Our Volunteer</option>
                        </select>
                                             </div>
                     <div class="col-sm-12 mt-3">
                        <div class="donate-now__personal-info-input">
                           <div class="checkbox privacypolicy">
                              <label for="checkboxes-0" class="trmcnd" style="font: 300 15px/20px 'Open Sans', sans-serif;">
                              <input style="width: 17px; margin-top: -5px;" type="checkbox" name="note" required value="Yes">By submitting this form, I declare that I am in good health and am willing to donate blood voluntarily in case of a medical emergency or as required by The Earth NGO. I understand that The Earth NGO will use my personal information only for the purpose of blood donation and will keep my information confidential.</label>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
            <div class="modal-footer">
            <button type="submit" class="btn  btn-primary">Save</button>
            <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </form>
         </div>
      </div>
   </div>
   <!-- Modal -->
   <!-- Modal -->
   <div class="modal" id="need_blood">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header" style="background: #03c0a8;">
               <div class="section-title text-center mb-1 mt-1">
                  <span class="section-title__tagline" style="color:#ffffff;">Need Blood</span>
               </div>
               <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="exampleModal">
               <form action="https://theearth.ngo/need/blood/store" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="_token" value="">                  <div class="form-group ">
                     <label for="recipient-name" class="col-form-label">Patient Name *</label>
                     <input type="text" class="form-control " id="recipient-name" name="p_name" required placeholder="Patient Name" value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Patient Dob  *</label>
                     <input name="dob" type="date" class="form-control " required  value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Attendee Name *</label>
                     <input name="a_name" type="text" class="form-control " placeholder="Enter Attendee Name " required value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Attendee Mobile Number *</label>
                     <input name="mobile" type="text" class="form-control " placeholder="Enter Mobile" required value="">
                                       </div>
                  <div class="form-group col-md-12 col-12">
                     <label for="message-text" class="col-form-label">Select Blood Group *</label>
                     <select class="form-control " name="blood_group" required>
                        <option selected disabled>Select Blood Group </option>
                        <option value="A+">A+</option>
                        <option value="A-" >A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="Don't Know">Don't Know</option>
                     </select>
                                       </div>
                  <div class="form-group col-md-12 col-12">
                     <label for="message-text" class="col-form-label">Select Blood Component *</label>
                     <select class="form-control " name="component" required>
                        <option selected disabled>Select  Component</option>
                        <option value="Blood">Blood </option>
                        <option value="Platelets">Platelets</option>
                     </select>
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Required Date *</label>
                     <input name="required_date" type="date" class="form-control " required value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Units  *</label>
                     <input name="unit" type="number" class="form-control " placeholder="Enter Unit" required value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Location For Donation *</label>
                     <input name="address" type="text" class="form-control " placeholder="Enter address" required value="">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Requisition Form From Doctor ( Image) *</label>
                     <input name="image" type="file" class="form-control " required>
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Refer By ( If any ) *</label>
                     <input name="refer_by" type="text" class="form-control " placeholder="Enter Refer By" required value="">
                                       </div>
            </div>
            <div class="modal-footer">
            <button type="submit" class="btn  btn-primary">Save</button>
            <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </form>
         </div>
      </div>
   </div>
   <!-- Modal -->
   <div class="modal fade" id="career_enquiry" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header" style="background: #00715D;">
               <div class="section-title text-center mb-1 mt-1">
                  <span class="section-title__tagline" style="color:#FBD45A;">Support Ticket</span>
               </div>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body" id="exampleModal">
               <form action="https://theearth.ngo/ticket/store" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="_token" value="">                  <div class="form-group ">
                     <label for="recipient-name" class="col-form-label">Title Name *</label>
                     <input type="text" class="form-control" id="recipient-name" name="title" placeholder="Enter Title">
                  </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Subject *</label>
                     <input name="suject" type="text" class="form-control " required placeholder="Enter Subject">
                                       </div>
                  <div class="form-group">
                     <label for="recipient-name" class="col-form-label">Email *</label>
                     <input name="email" type="text" class="form-control " placeholder="Enter Email" required>
                                       </div>
                  <div class="form-group">
                     <label for="message-text" class="col-form-label">Priority *</label>
                     <select class="form-control" name="Priority">
                        <option selected disabled>Select Priority</option>
                        <option value="Low">Low</option>
                        <option value="Medium" >Medium</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                     </select>
                  </div>
                  <div class="form-group">
                     <label for="message-text" class="col-form-label">Issues *</label>
                     <select class="form-control" name="departments">
                        <option selected disabled>Select Department</option>
                        <option value="Submit Issue">Submit Issue</option>
                        <option value="Login Issue">Login Issue</option>
                        <option value="Payment Issue">Payment Issue</option>
                        <option value="Cause Issue">Cause Issue</option>
                     </select>
                  </div>
                  <div class="form-group">
                     <label for="message-text" class="col-form-label">Description *</label>
                     <textarea cols="80" class="tinymce-editor"  name="editor1" rows="10" data-sample-short ></textarea>
                                       </div>
            </div>
            <div class="modal-footer">
            <button type="submit" class="btn  btn-primary">Save</button>
            <button type="button" class="btn  btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </form>
         </div>
      </div>
   </div>
   </div>
   <!-- scroll to top -->
   <button class="scroll-top scroll-to-target" data-target="html">
   <i class="far fa-long-arrow-up"></i>
   </button>
   </div>
   <!-- jequery plugins -->
   <script src="https://theearth.ngo/public/web/assets/js/jquery.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/popper.min.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/bootstrap.min.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/owl.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/swiper.min.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/wow.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/validation.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/jquery.fancybox.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/appear.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/scrollbar.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/isotope.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/nav-tool.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/jquery.bootstrap-touchspin.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/countdown.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/plugins.js"></script>
   <script src="https://theearth.ngo/public/web/assets/js/text_animation.js"></script>
   
   <script src="https://theearth.ngo/public/web/assets/js/script.js"></script>
   <script src="https://theearth.ngo/public/assets/plugins/sweetalert/sweetalert.min.js"></script>
   <script src="https://theearth.ngo/public/assets/plugins/sweetalert/ac-alert.js"></script>
   <script src="https://theearth.ngo/public/assets/plugins/tinymce/tinymce.min.js"></script>
      <script>
        $(document).ready(function()
        {
            $("body").bind('cut copy paste' ,function(e)
            {
                e.preventDefault();
            });
        });
    
    document.onkeydown=function(e)
    {
            if(event.keyCode ==123)
        {
            return false;
        }
        if(e.ctrlKey && e.shiftKey && e.keyCode =='I'.charCodeAt(0))
        {
            return false;
        }
    
    if(e.ctrlKey && e.shiftKey && e.keyCode =='J'.charCodeAt(0))
        {
            return false;
        }
    
    if(e.ctrlKey && e.shiftKey && e.keyCode =='U'.charCodeAt(0))
        {
            return false;
        }
    
    }
    </script>
    
   <script type="text/javascript">
      // tinymce editor
      $(window).on('load', function() {
          tinymce.init({
              selector: '.tinymce-editor',
              height: 200,
              theme: 'modern',
              plugins: [
                  'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                  'searchreplace wordcount visualblocks visualchars code fullscreen',
                  'insertdatetime media nonbreaking save table contextmenu directionality',
                  'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
              ],
              toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
              toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
              image_advtab: true
          });
      });
   </script>
   <script>
         </script>
   <script>
         </script>
   <script>
      $(function () {
          $("#example1").DataTable({
              "responsive": true, "lengthChange": true, "autoWidth": false,
              "buttons": ["csv", "excel", "pdf", "print"]
          }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      });
   </script>
   <script>
      $("#chkSelectAll").on('click', function(){
           this.checked ? $(".chkDel").prop("checked",true) : $(".chkDel").prop("checked",false);  
      })
   </script>
   <script >
      $(document).ready(function () {
      $('.table').on('click', '.delete_button_action', function (e) {
          var id = $(this).attr('data-id');
          var url = $(this).attr('data-url');
          var token = '';
          $(".remove-record-model").attr("action", url);
          $('body').find('.remove-record-model').append('<input name="_token" type="hidden" value="' + token + '">');
          $('body').find('.remove-record-model').append('<input name="_method" type="hidden" value="DELETE">');
          $('body').find('.remove-record-model').append('<input name="id" type="hidden" value="' + id + '">');
      });
      $('.remove-data-from-delete-form').click(function () {
          $('body').find('.remove-record-model').find("input").remove();
      });
      });
   </script>
   <!-- ./wrapper -->
   <div class="modal fade" id="delete_button_modal" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-sm" role="document">
         <div class="modal-content">
            <form action="" method="POST" class="remove-record-model">
               <div class="modal-header">
                  <h4 class="title" id="smallModalLabel">Confirmation</h4>
               </div>
               <div class="modal-body">
                  <p>Are you sure want to delete?</p>
               </div>
               <div class="modal-footer">
                  <button type="submit" class="btn btn-success waves-effect waves-light">YES</button>
                  <button type="button" class="btn btn-danger waves-effect m-l-5 remove-record-model" data-dismiss="modal">No</button>
               </div>
            </form>
         </div>
      </div>
   </div>
</body>
</html>